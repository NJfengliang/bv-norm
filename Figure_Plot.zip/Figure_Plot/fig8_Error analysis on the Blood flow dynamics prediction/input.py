# -*- coding:utf-8 -*-
# @Time ： 2024/1/30 19:29
# @Author ： Fengliang
# @File ： input.py
# @Software： PyCharm


import numpy as np
import matplotlib.pyplot as plt
import random

import scipy.io as sio
import matplotlib.pyplot as plt
import matplotlib.tri as mtri
import numpy as np
# from lapy import TriaMesh
import matplotlib
import seaborn as sns
from matplotlib import cm
matplotlib.rcParams['mathtext.fontset'] = 'cm' # 设置公式字体 STIX
plt.rc('font', family='arial', size=16)


def VVelocity(t, mean, sigma):
    # if t >= 0 and t <= 0.3:
    #     return 0.335 * t + (0.9 * np.exp(-((0.3 - mean) ** 2) / (2 * sigma ** 2)) + 0.1 - 0.3 * 0.335)
    # if t > 0.3 and t <= 1.5:
    return 0.9 * np.exp(-((t - mean) ** 2) / (2 * sigma ** 2)) + 0.1


def PPressure(t, mean, sigma):
    # if t >= 0 and t <= 0.3:
    #     return 0.6 * np.sin((t + 0.2) * np.pi) + (0.4 * np.exp(-1 * (0.3 - mean) ** 2 / (2 * sigma)) + 0.6 - 0.6)
    # if t > 0.3 and t <= 1.5:
    return 0.4 * np.exp(-1 * (t - mean) ** 2 / (2 * sigma)) + 0.6


# V_weight = [VVelocity(t) for t in np.linspace(0,1.5,100)]
# P_weight = [PPressure(t) for t in np.linspace(0,1.5,100)]

plt.figure()

for i in range(5):
    mean = random.randint(70, 110) * 0.01
    sigma = random.randint(10, 15) * 0.01
    colors = [(62/256,237/256,231/256),(48/256,223/256,243/256),(68/256,206/256,246/256),(174/256,208/256,238/256),(73/256,148/256,196/256)]


    V_weight = [VVelocity(t, mean, sigma) for t in np.linspace(0, 1.5, 100)]
    # sns.set_theme(style="ticks")

    plt.plot(np.linspace(0, 1.5, 100), V_weight, linewidth=4,color=colors[i])
    sns.despine()
    # plt.title("Vecity")
#
# # plt.figure()
plt.savefig('input/v' + '.svg',format='svg')


# for i in range(1):
#     mean = random.randint(70, 110) * 0.01
#     sigma = random.randint(10, 20) * 0.001
#
#     P_weight = [PPressure(t, mean, sigma) for t in np.linspace(0, 1.5, 100)]
#
#     plt.plot(np.linspace(0, 1.5, 100), P_weight, linewidth=4,color='#b22408')
#     sns.despine()
#
#
#
#
#     # plt.title("Pressure")#b22408,color='#b22408'
#     # plt.show()
#
# plt.savefig('p'  + '.svg',format='svg')


plt.show()

