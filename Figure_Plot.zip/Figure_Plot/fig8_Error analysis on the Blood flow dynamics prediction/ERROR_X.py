# -*- coding:utf-8 -*-
# @Time ： 2024/3/13 10:44
# @Author ： Fengliang
# @File ： test0.py
# @Software： PyCharm


import scipy.io as sio
import matplotlib.pyplot as plt
import matplotlib.tri as mtri
import numpy as np
# from lapy import TriaMesh
import matplotlib
import seaborn as sns
import pandas as pd
from scipy import stats
from matplotlib.ticker import FuncFormatter
matplotlib.rcParams['mathtext.fontset'] = 'cm' # 设置公式字体 STIX
plt.rc('font', family='arial', size=20)

#-----------------------------------------------------------------data
index_r ="X2"
path_X_DN = sio.loadmat( '../data/05.blood/DNORM/velocity_x_1/DNORM_pre.mat')
path_X_DE = sio.loadmat('../data/05.blood/DEEP/velocity_x_1/DeepONet_pre.mat')
path_X_PO = sio.loadmat('../data/05.blood/POD_D/velocity_x_1/POD_DeepONet_pre.mat')
path_X_NO = sio.loadmat('../data/05.blood/NORM/velocity_x_1/MeshNO_pre.mat')
#-----------------------------------------------------------------plot
# fig, axs = plt.subplots(figsize=(10,5))
# plt.subplots_adjust(left=0.08, right=0.95,bottom=0.06,top=0.9,wspace=0.2)
# grid = plt.GridSpec(1,4, wspace=0.25, hspace=0.12)

#-----------------------------------------------------------------Error of DNORM

# plt.subplot(grid[0,0])
# sns.set(style="whitegrid")
sns.set(style='ticks')

y_test_X_DN  = path_X_DN['y_test']
y_pre_X_DN = path_X_DN['pre_test']
y_pre_X_DE = path_X_DE['pre_test']
y_pre_X_PO = path_X_PO['pre_test']
y_pre_X_NO = path_X_NO['pre_test']

mean_error_DN = np.mean(y_test_X_DN-y_pre_X_DN,axis=(1))
max_error_DN = np.max(y_test_X_DN-y_pre_X_DN,axis=(1))
mean_error_DE = np.mean(y_test_X_DN-y_pre_X_DE,axis=(1))
max_error_DE = np.max(y_test_X_DN-y_pre_X_DE,axis=(1))
mean_error_PO = np.mean(y_test_X_DN-y_pre_X_PO,axis=(1))
max_error_PO = np.max(y_test_X_DN-y_pre_X_PO,axis=(1))
mean_error_NO = np.mean(y_test_X_DN-y_pre_X_NO,axis=(1))
max_error_NO = np.max(y_test_X_DN-y_pre_X_NO,axis=(1))

datadn = pd.DataFrame( {"mean_error":mean_error_DN,"max_error":max_error_DN,"METHODS": "BV-NORM"})
datade = pd.DataFrame( {"mean_error":mean_error_DE,"max_error":max_error_DE,"METHODS": "DeepONet"})
datapo = pd.DataFrame({"mean_error":mean_error_PO,"max_error":max_error_PO,"METHODS": "POD-DeepONet"})
datano = pd.DataFrame({"mean_error":mean_error_NO,"max_error":max_error_NO,"METHODS": "NORM"})

# df = pd.concat([datadn, datade, datapo ,datano])
cmap = sns.cubehelix_palette(start=2, light=1, as_cmap=True)
# flatui = ["#6a8ab1", "#b05e5b", "#8FC2C7", "#B4B6B6"]
# flatui = ["#f56e68", "#1597a5", "#0e606c", "#ffc249"]
# flatui = ["#e83747", "#a9dbdc", "#457b9d", "#1d355b"]
df = pd.concat([datano, datade, datapo ,datadn])
# flatui = ["#6a8ab1", "#b05e5b", "#8FC2C7", "#B4B6B6"]
# flatui = ["#BD514A", "#488B87", "#47626d", "#014c68"]
flatui = ["#1d355b", "#a9dbdc", "#457b9d", "#e83747"]
plt.figure(figsize=(10, 6))
g = sns.jointplot(data=df, x="mean_error", y="max_error", hue="METHODS",kind = "scatter", palette=flatui
        )
g.ax_joint.set_xlabel('Mean Error', fontsize=16)
g.ax_joint.set_ylabel('Max Error', fontsize=16)
g.ax_joint.tick_params(labelsize=18)
# plt.title('ERROR distribution of DNORM', fontsize=16),kind = "hist",kde,scatter

# Set specific tick marks on the x-axis and y-axis
g.ax_joint.set_xticks(np.linspace(g.ax_joint.get_xlim()[0], g.ax_joint.get_xlim()[1], 4))
# g.ax_joint.set_yticks(np.linspace(g.ax_joint.get_ylim()[0], g.ax_joint.get_ylim()[1], 4))

# Formatter functions to set tick labels to the desired decimal places
formatter_x = FuncFormatter(lambda x, _: f'{x:.4f}')
# formatter_y = FuncFormatter(lambda y, _: f'{y:.3f}')
g.ax_joint.xaxis.set_major_formatter(formatter_x)
# g.ax_joint.yaxis.set_major_formatter(formatter_y)

plt.setp(g.ax_joint.get_legend().get_texts(), fontsize=14)  # for legend text
plt.setp(g.ax_joint.get_legend().get_title(), fontsize=16)  # for legend title
g.ax_joint.get_legend().set_title('')

plt.tight_layout()
plt.savefig('error_d/error' + str(index_r) + '.svg',format='svg')
plt.savefig('error_d/error' + str(index_r) + '.pdf',format='pdf')
plt.show()