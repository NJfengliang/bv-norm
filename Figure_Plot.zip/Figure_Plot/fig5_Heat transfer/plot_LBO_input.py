# -*- coding: utf-8 -*-
"""
Created on Thu Dec 22 13:54:15 2022

@author: GengxiangCHEN
"""

import scipy.io as sio
import matplotlib.pyplot as plt
import matplotlib.tri as mtri
import numpy as np
import pyvista as pv
# from lapy import TriaMesh
import matplotlib

# matplotlib.rcParams['backend'] = 'SVG'
matplotlib.rcParams['mathtext.fontset'] = 'cm' # 设置公式字体 STIX
plt.rc('font', family='arial', size=12)

mesh = pv.read('../data/02.heat/lbo_basis/0807_D8_InputMesh.stl')
input_points = mesh.points
faces = mesh.faces.reshape(-1, 4)
faces = faces[:,1:4]
triang = mtri.Triangulation(input_points[:,0], input_points[:,1], faces)


PATH = '../data/02.heat/lbo_basis/lbe_ev_input.mat'
data = sio.loadmat(PATH)
x_data = data['Eigenvectors'].T
# y_data = data['output']

fig, axs = plt.subplots(figsize=(12,4))
plt.subplots_adjust(left=0.08, right=0.95,bottom=0.16,top=0.9,wspace=0.2)
index = 1
segment = 'darcy'

########## DIY colorbar ##########
from matplotlib import cm
from matplotlib.colors import ListedColormap
top = cm.get_cmap('Blues_r', 128)
bottom = cm.get_cmap('Reds', 128)

newcolors = np.vstack((top(np.linspace(0, 1, 128)),
                       bottom(np.linspace(0, 1, 128)))) *0.98
newcmp = ListedColormap(newcolors, name='OrangeBlue')

########## DeeoOnet ########
ntrain = 0
ntest = 0

# data = sio.loadmat('../data/02.heat/pre/DNORM_pre.mat')
x_test   = x_data[index]
# pre_test = data['pre_test'][index]
# y_test   = data['y_test'][index]

# Plot the triangulation.
# ax = plt.subplot(1,2,1)
# ax.set_aspect(1)
# cs = plt.tricontourf(triang, x_test, np.linspace(3, 15, 5), cmap='plasma', alpha=0.01)
# plt.triplot(triang,linewidth=0.5, markersize=0.2)
# cb = plt.colorbar(cs, location = 'right',shrink=0.8)
# cb.set_ticks([ ])
# # cb.set_ticklabels(('0', '0.4', '0.6', '0.8', '1.0'))
# # cb.set_label('Probability of Chatter')
# cb.ax.tick_params(labelsize=12)
# # plt.xlim([0,1])
# # plt.ylim([0,0.8])
# plt.title('(a) Mesh ', fontsize=12)


# Plot the triangulation.RdBu_r plasma_r
ax = plt.subplot(1,3,1)
ax.set_aspect(1)
cs = plt.tricontourf(triang, x_data[0], 15, cmap='RdBu_r')
ax.axis('off')
# plt.triplot(triang,linewidth=0.5, markersize=0.2,color='gray')
# cb = plt.colorbar(cs, location = 'right',shrink=0.8)
# cb.set_ticks([ 260, 270, 280, 290])
# cb.set_ticklabels(('0', '0.4', '0.6', '0.8', '1.0'))
# cb.set_label('Probability of Chatter')
# cb.ax.tick_params(labelsize=12)
# plt.xlim([0,1])
# plt.ylim([0,0.8])
# plt.title(' LBO_basis_input 1', fontsize=12)


ax = plt.subplot(1,3,2)
ax.set_aspect(1)
cs = plt.tricontourf(triang, x_data[1], 15, cmap='RdBu_r')
ax.axis('off')
# plt.triplot(triang,linewidth=0.5, markersize=0.2,color='gray')
# cb = plt.colorbar(cs, location = 'right',shrink=0.8)
# cb.set_ticks([ 260, 270, 280, 290])
# cb.set_ticklabels(('0', '0.4', '0.6', '0.8', '1.0'))
# cb.set_label('Probability of Chatter')
# cb.ax.tick_params(labelsize=12)
# plt.xlim([0,1])
# plt.ylim([0,0.8])
# plt.title(' LBO_basis_input 2', fontsize=12)


ax = plt.subplot(1,3,3)
ax.set_aspect(1)
ax.axis('off')
cs = plt.tricontourf(triang, x_data[2], 15, cmap='RdBu_r')
# plt.triplot(triang,linewidth=0.5, markersize=0.2,color='gray')
# cb = plt.colorbar(cs, location = 'right',shrink=0.8)
# cb.set_ticks([ 260, 270, 280, 290])
# cb.set_ticklabels(('0', '0.4', '0.6', '0.8', '1.0'))
# cb.set_label('Probability of Chatter')
# cb.ax.tick_params(labelsize=12)
# plt.xlim([0,1])
# plt.ylim([0,0.8])
# plt.title(' LBO_basis_input 3', fontsize=12)


fig.tight_layout()
plt.savefig('figs/ba/input' + str(index) + '.svg',format='svg')
plt.savefig('figs/ba/input' + str(index) + '.pdf',format='pdf')



plt.show()