# -*- coding: utf-8 -*-
"""
Created on Thu Nov 10 10:59:35 2022

@author: GengxiangCHEN
"""

import numpy as np
import pyvista as pv
import pandas as pd
import matplotlib.pyplot as plt
import torch
import matplotlib 
import scipy.io as sio
from matplotlib import cm
from pyvista import CellType

# matplotlib.rcParams['backend'] = 'SVG'
matplotlib.rcParams['mathtext.fontset'] = 'cm' # 设置公式字体 STIX 
plt.rc('font', family='arial', size=16)
pv.rcParams['transparent_background'] = True
from matplotlib.colors import ListedColormap, LinearSegmentedColormap

import warnings
warnings.simplefilter("ignore")
import os
os.environ['KMP_DUPLICATE_LIB_OK']='True'


########## Color bar ################
jet = cm.get_cmap('turbo', 256)
newcolors = jet(np.linspace(0.1, 1, 256))
newcmp = ListedColormap(newcolors)

#####################################
output_mesh_points = sio.loadmat('../data/02.heat/Part_Mesh.mat')
points = output_mesh_points['points']
faces  = output_mesh_points['elements'] - 1
faces  = faces.astype(int)

celltypes = np.full(faces.shape[0], fill_value=CellType.TETRA, dtype=np.uint8)
cells     = np.hstack((np.full((faces.shape[0], 1), 4), faces))

mesh = pv.UnstructuredGrid(cells, celltypes, points)
########## DeeoOnet ########
data = sio.loadmat('../data/02.heat/pre/DeepONet_pre.mat')
D_real_DON  = data['y_test']
D_pred_DON  = data['pre_test']

########## POD-DON ########
data = sio.loadmat('../data/02.heat/pre/POD_DeepONet_pre.mat')
D_real_PON  = data['y_test']
D_pred_PON  = data['pre_test']

########## dnorm ########
data = sio.loadmat('../data/02.heat/pre/DNORM_pre.mat')
D_real_DNO  = data['y_test']
D_pred_DNO  = data['pre_test']

########### norm ########
data = sio.loadmat('../data/02.heat/pre/MeshNO_pre.mat')
D_real_NO = data['y_test']
D_pred_NO = data['pre_test']

##### Plot SVD Fig #####

i = 60
  
if 1:
    pv.global_theme.show_scalar_bar = True
       
    ###  DON 重构误差  ### 
    D_recon = D_pred_DON
    D_real  = D_real_DON
    mesh.point_data['T(K)'] = D_recon[i,:] - D_real[i,:]
    Max = np.max(D_recon[i,:] - D_real[i,:])
    Min = np.min(D_recon[i,:] - D_real[i,:])
    Max_bar = np.abs(2.5)
    
    # Max_bar = 0.129
    print('Max DON : ' , np.max(np.abs((D_recon[i,:] - D_real[i,:]))))
    pl = pv.Plotter(off_screen=True)
    
    sargs = dict(height=0.65, 
                 vertical=True,
                 position_x=0.90,
                 position_y=0.20,
                 title_font_size=30,
                 label_font_size=25,
                 color = 'black',
                 font_family="arial")
    
    pl.add_mesh(mesh, scalars='T(K)', cmap='RdBu_r', scalar_bar_args=sargs)
    pl.add_text('Max Error = ' + str(np.round(np.max(np.abs(D_recon[i,:] - D_real[i,:])), 3)) + 'K', 
                position='lower_edge', color='black', font='arial',
                shadow=True, font_size=14)

    pl.camera.position = (-98.24647470106407, 57.735116870463614, -152.91745928400286)
    pl.camera.focal_point = (104.24166297136696, -59.09799482571239, 186.75633167549972)
    pl.camera.up =  (0.25296891917256037, 0.9512586611058352, 0.17639071858746022)
    pl.camera.zoom(1.6)
    pl.update_scalar_bar_range([-Max_bar, Max_bar])
    # pl.screenshot(screenshot='fig/lbo_'+str(i)+'.png')   
    cpos = pl.show(screenshot='figs/e/DeepOnet_error_'+str(i)+'.png', return_cpos=True)

       
    ###  GP 重构误差  ### 
    # D_recon = D_recon_GP
    # D_real = D_reald_GP
    # mesh.point_data['D(mm)'] = D_recon[i,:] - D_real[i,:]
    # # Max_bar = np.max(D_recon[i,:] - D_real[i,:])
    # print('Max GP : ' , np.max(np.abs((D_recon[i,:] - D_real[i,:]))))
    # pl = pv.Plotter(off_screen=True)
    
    # sargs = dict(height=0.65, 
    #              vertical=True, 
    #              position_x=0.05, 
    #              position_y=0.15,
    #              title_font_size=30,
    #              label_font_size=25,
    #              color = 'black',
    #              font_family="arial")
    
    # pl.add_mesh(mesh, scalars='D(mm)', cmap=newcmp, scalar_bar_args=sargs)
    # pl.add_text('Max Error = ' + str(np.round(np.max(np.abs(D_recon[i,:] - D_real[i,:])), 3)) + 'mm', 
    #             position='lower_edge', color='black', font='arial',
    #             shadow=True, font_size=14)
    
    # pl.camera.position = (917.9775486078297, -328.2218052311738, 117.89930903584482)
    # pl.camera.focal_point = (-170.04071396866132, 183.54521717632534, 158.37018115280372)
    # pl.camera.up =  (-0.05885809084753644, -0.046273781810935784, -0.9971932923253631)
    # pl.camera.zoom(1.6)
    # pl.update_scalar_bar_range([-Max_bar, Max_bar])
    # # pl.screenshot(screenshot='fig/lbo_'+str(i)+'.png')   
    # cpos = pl.show(screenshot='figs/ErrorPredict/GP_error_'+str(i)+'.png', return_cpos=True)
       


    ############### POD  ###############
    D_recon = D_pred_PON
    D_real  = D_real_PON
    mesh.point_data['T(K)'] = D_recon[i,:] - D_real[i,:]
    pl = pv.Plotter(off_screen=True)
    print('Max PON : ' , np.max(np.abs(D_recon[i,:] - D_real[i,:])))
    sargs = dict(height=0.65, 
                 vertical=True,
                 position_x=0.90,
                 position_y=0.20,
                 title_font_size=30,
                 label_font_size=25,
                 color = 'black',
                 font_family="arial")
    
    pl.add_mesh(mesh, scalars='T(K)', cmap='RdBu_r', scalar_bar_args=sargs)
    pl.add_text('Max Error = ' + str(np.round(np.max(np.abs(D_recon[i,:] - D_real[i,:])), 3)) + 'K', 
                position='lower_edge', color='black', font='arial',
                shadow=True, font_size=14)
    
    pl.camera.position = (-98.24647470106407, 57.735116870463614, -152.91745928400286)
    pl.camera.focal_point = (104.24166297136696, -59.09799482571239, 186.75633167549972)
    pl.camera.up =  (0.25296891917256037, 0.9512586611058352, 0.17639071858746022)
    pl.camera.zoom(1.6)
    pl.update_scalar_bar_range([-Max_bar, Max_bar])
    # pl.screenshot(screenshot='fig/lbo_'+str(i)+'.png')   
    cpos = pl.show(screenshot='figs/e/POD_DeepOnet_error_'+str(i)+'.png', return_cpos=True)
    
    ############### LNO  ###############    
    D_recon = D_pred_DNO
    D_real  = D_real_DNO
    mesh.point_data['T(K)'] = D_recon[i,:] - D_real[i,:]
    pl = pv.Plotter(off_screen=True)
    print('Max DNORM : ' , np.max(np.abs(D_recon[i,:] - D_real[i,:])))
    sargs = dict(height=0.65, 
                 vertical=True, 
                 position_x=0.90,
                 position_y=0.20,
                 title_font_size=30,
                 label_font_size=25,
                 color = 'black',
                 font_family="arial")
    
    pl.add_mesh(mesh, scalars='T(K)', cmap='RdBu_r', scalar_bar_args=sargs)
    pl.add_text('Max Error = ' + str(np.round(np.max(np.abs(D_recon[i,:] - D_real[i,:])), 3)) + 'K', 
                position='lower_edge', color='black', font='arial',
                shadow=True, font_size=14)

    pl.camera.position = (-98.24647470106407, 57.735116870463614, -152.91745928400286)
    pl.camera.focal_point = (104.24166297136696, -59.09799482571239, 186.75633167549972)
    pl.camera.up = (0.25296891917256037, 0.9512586611058352, 0.17639071858746022)
    pl.camera.zoom(1.6)
    pl.update_scalar_bar_range([-Max_bar, Max_bar])
    # pl.screenshot(screenshot='fig/lbo_'+str(i)+'.png')   
    cpos = pl.show(screenshot='figs/e/DNORM_error_'+str(i)+'.png', return_cpos=True)

    ############### LNO  ###############
    D_recon = D_pred_NO
    D_real = D_real_NO
    mesh.point_data['T(K)'] = D_recon[i, :] - D_real[i, :]
    pl = pv.Plotter(off_screen=True)
    print('Max NORM : ', np.max(np.abs(D_recon[i, :] - D_real[i, :])))
    sargs = dict(height=0.65,
                 vertical=True,
                 position_x=0.90,
                 position_y=0.20,
                 title_font_size=30,
                 label_font_size=25,
                 color='black',
                 font_family="arial")

    pl.add_mesh(mesh, scalars='T(K)', cmap='RdBu_r', scalar_bar_args=sargs)
    pl.add_text('Max Error = ' + str(np.round(np.max(np.abs(D_recon[i, :] - D_real[i, :])), 3)) + 'K',
                position='lower_edge', color='black', font='arial',
                shadow=True, font_size=14)

    pl.camera.position = (-98.24647470106407, 57.735116870463614, -152.91745928400286)
    pl.camera.focal_point = (104.24166297136696, -59.09799482571239, 186.75633167549972)
    pl.camera.up = (0.25296891917256037, 0.9512586611058352, 0.17639071858746022)
    pl.camera.zoom(1.6)
    pl.update_scalar_bar_range([-Max_bar, Max_bar])
    # pl.screenshot(screenshot='fig/lbo_'+str(i)+'.png')
    cpos = pl.show(screenshot='figs/e/NORM_error_' + str(i) + '.png', return_cpos=True)
    

##### 画出重构 #####
if 0:
    pv.global_theme.show_scalar_bar = True
    ############### LNO  ###############    
    D_recon = D_pred_LNO
    D_real  = D_real_LNO
    
    Max = np.max(D_real[i,:])
    Min = np.min(D_real[i,:])
    # Max_bar = np.max((abs(Max), abs(Min)))
    
    mesh.point_data['T(K)'] = D_recon[i,:]
    pl = pv.Plotter(off_screen=True)
    # print('Max LNO : ' , np.max(np.abs(D_recon[i,:] - D_real[i,:])))
    sargs = dict(height=0.65, 
                 vertical=True, 
                 position_x=0.05, 
                 position_y=0.15,
                 title_font_size=30,
                 label_font_size=25,
                 color = 'black',
                 font_family="arial")
    
    pl.add_mesh(mesh, scalars='T(K)', cmap='plasma_r', scalar_bar_args=sargs)
    pl.add_text('Max Error = ' + str(np.round(np.max(np.abs(D_recon[i,:] - D_real[i,:])), 3)) + 'mm', 
                position='lower_edge', color='black', font='arial',
                shadow=True, font_size=14)
    
    pl.camera.position = (-98.24647470106407, 57.735116870463614, -152.91745928400286)
    pl.camera.focal_point = (104.24166297136696, -59.09799482571239, 186.75633167549972)
    pl.camera.up =  (0.25296891917256037, 0.9512586611058352, 0.17639071858746022)
    pl.camera.zoom(1.6)
    pl.update_scalar_bar_range([Min, Max])
    # pl.screenshot(screenshot='fig/lbo_'+str(i)+'.png')   
    cpos = pl.show(screenshot='figs/LNO_pred_'+str(i)+'.png', return_cpos=True)
    
    ############### LNO  ###############    
    D_recon = D_pred_LNO
    D_real  = D_real_LNO
    mesh.point_data['T(K)'] = D_real[i,:]
    pl = pv.Plotter(off_screen=True)
    # print('Max LNO : ' , np.max(np.abs(D_recon[i,:] - D_real[i,:])))
    sargs = dict(height=0.65, 
                 vertical=True, 
                 position_x=0.05, 
                 position_y=0.15,
                 title_font_size=30,
                 label_font_size=25,
                 color = 'black',
                 font_family="arial")
    
    pl.add_mesh(mesh, scalars='T(K)', cmap='plasma_r', scalar_bar_args=sargs)
    pl.add_text('Max Error = ' + str(np.round(np.max(np.abs(D_recon[i,:] - D_real[i,:])), 3)) + 'mm', 
                position='lower_edge', color='black', font='arial',
                shadow=True, font_size=14)
    
    pl.camera.position = (-98.24647470106407, 57.735116870463614, -152.91745928400286)
    pl.camera.focal_point = (104.24166297136696, -59.09799482571239, 186.75633167549972)
    pl.camera.up =  (0.25296891917256037, 0.9512586611058352, 0.17639071858746022)
    pl.camera.zoom(1.6)
    pl.update_scalar_bar_range([Min, Max])
    # pl.screenshot(screenshot='fig/lbo_'+str(i)+'.png')   
    cpos = pl.show(screenshot='figs/Real_'+str(i)+'.png', return_cpos=True)
    
    ############### DON  ###############    
    D_recon = D_pred_DON
    D_real  = D_real_DON
    mesh.point_data['T(K)'] = D_recon[i,:]
    pl = pv.Plotter(off_screen=True)
    print('Max LNO : ' , np.max(np.abs(D_recon[i,:] - D_real[i,:])))
    sargs = dict(height=0.65, 
                 vertical=True, 
                 position_x=0.05, 
                 position_y=0.15,
                 title_font_size=30,
                 label_font_size=25,
                 color = 'black',
                 font_family="arial")
    
    pl.add_mesh(mesh, scalars='T(K)', cmap='plasma_r', scalar_bar_args=sargs)
    pl.add_text('Max Error = ' + str(np.round(np.max(np.abs(D_recon[i,:] - D_real[i,:])), 3)) + 'mm', 
                position='lower_edge', color='black', font='arial',
                shadow=True, font_size=14)
    
    pl.camera.position = (-98.24647470106407, 57.735116870463614, -152.91745928400286)
    pl.camera.focal_point = (104.24166297136696, -59.09799482571239, 186.75633167549972)
    pl.camera.up =  (0.25296891917256037, 0.9512586611058352, 0.17639071858746022)
    pl.camera.zoom(1.6)
    pl.update_scalar_bar_range([Min, Max])
    # pl.screenshot(screenshot='fig/lbo_'+str(i)+'.png')   
    cpos = pl.show(screenshot='figs/DON_pre_'+str(i)+'.png', return_cpos=True)
    
    ############### PON  ###############    
    D_recon = D_pred_PON
    D_real  = D_real_PON
    mesh.point_data['T(K)'] = D_recon[i,:]
    pl = pv.Plotter(off_screen=True)
    print('Max LNO : ' , np.max(np.abs(D_recon[i,:] - D_real[i,:])))
    sargs = dict(height=0.65, 
                 vertical=True,
                 position_x=0.90,
                 position_y=0.20,
                 title_font_size=30,
                 label_font_size=25,
                 color = 'black',
                 font_family="arial")
    
    pl.add_mesh(mesh, scalars='T(K)', cmap='plasma_r', scalar_bar_args=sargs)
    pl.add_text('Max Error = ' + str(np.round(np.max(np.abs(D_recon[i,:] - D_real[i,:])), 3)) + 'mm', 
                position='lower_edge', color='black', font='arial',
                shadow=True, font_size=14)
    
    pl.camera.position = (-98.24647470106407, 57.735116870463614, -152.91745928400286)
    pl.camera.focal_point = (104.24166297136696, -59.09799482571239, 186.75633167549972)
    pl.camera.up =  (0.25296891917256037, 0.9512586611058352, 0.17639071858746022)
    pl.camera.zoom(1.6)
    pl.update_scalar_bar_range([Min, Max])
    # pl.screenshot(screenshot='fig/lbo_'+str(i)+'.png')   
    cpos = pl.show(screenshot='figs/PON_pre_'+str(i)+'.png', return_cpos=True)
    

                
    