# -*- coding: utf-8 -*-
"""
Created on Thu Nov 10 10:59:35 2022

@author: GengxiangCHEN
"""

import numpy as np
import pyvista as pv
import pandas as pd
import matplotlib.pyplot as plt
import torch
import matplotlib
import scipy.io as sio
from matplotlib import cm
from pyvista import CellType

# matplotlib.rcParams['backend'] = 'SVG'
matplotlib.rcParams['mathtext.fontset'] = 'cm'  # 设置公式字体 STIX
plt.rc('font', family='arial', size=16)
pv.rcParams['transparent_background'] = True
from matplotlib.colors import ListedColormap, LinearSegmentedColormap

import warnings

warnings.simplefilter("ignore")
import os

os.environ['KMP_DUPLICATE_LIB_OK'] = 'True'

########## Color bar ################
jet = cm.get_cmap('turbo', 256)
newcolors = jet(np.linspace(0.1, 1, 256))
newcmp = ListedColormap(newcolors)

#####################################
output_mesh_points = sio.loadmat('../data/02.heat/Part_Mesh.mat')
points = output_mesh_points['points']
faces = output_mesh_points['elements'] - 1
faces = faces.astype(int)

celltypes = np.full(faces.shape[0], fill_value=CellType.TETRA, dtype=np.uint8)
cells = np.hstack((np.full((faces.shape[0], 1), 4), faces))

mesh = pv.UnstructuredGrid(cells, celltypes, points)
# mesh.plot(show_axes=True, show_edges=True)
# cpos = pl.show(screenshot='figs/000_'+str(i)+'.png', return_cpos=False)
# print(cpos)


PATH = '../data/02.heat/data_heat_3.mat'
PATH2 = '../data/02.heat/pre/DNORM_pre.mat'
data = sio.loadmat(PATH)
Data2 = sio.loadmat(PATH2)
# x_data = data['input']
# y_data = data['output']
y_data = Data2['y_test']
p_data = Data2['pre_test']

index = 12

ntest = 90

y_plot = y_data[-ntest:, :][index]
p_plot = p_data[-ntest:, :][index]

# x_plot = x_data[index]
# y_plot = y_data[index]
########### ReduceOeder ########
# dataGP = sio.loadmat('../data/GP_modes_100_pre_200.mat')
# D_reald_GP = dataGP['y_test_Deform']
# D_recon_GP = dataGP['pre_test_Deform']

##### Plot SVD Fig #####
if 1:
    pv.global_theme.show_scalar_bar = True
    i = 0

    mesh.point_data['T(K)'] = y_plot
    Max = np.max(y_plot)
    Min = np.min(y_plot)
    # Max_bar = np.max((abs(Max), abs(Min)))

    # Max_bar = 0.129
    # print('Max DON : ' , np.max(np.abs((D_recon[i,:] - D_real[i,:]))))
    pl = pv.Plotter(off_screen=True)

    sargs = dict(height=0.65,
                 vertical=True,
                 position_x=0.90,
                 position_y=0.20,
                 title_font_size=30,
                 label_font_size=25,
                 color='black',
                 font_family="arial")

    pl.add_mesh(mesh, scalars='T(K)', cmap='RdBu_r', scalar_bar_args=sargs)
    # pl.add_text('Max Error = ' + str(np.round(np.max(np.abs(D_recon[i,:] - D_real[i,:])), 3)) + 'mm',
    #             position='lower_edge', color='black', font='arial',
    #             shadow=True, font_size=14)
    pl.camera.position = (-98.24647470106407, 57.735116870463614, -152.91745928400286)
    pl.camera.focal_point = (104.24166297136696, -59.09799482571239, 186.75633167549972)
    pl.camera.up = (0.25296891917256037, 0.9512586611058352, 0.17639071858746022)
    pl.camera.zoom(1.6)

    pl.update_scalar_bar_range([Min, Max])
    # pl.screenshot(screenshot='fig/lbo_'+str(i)+'.png')
    cpos = pl.show(screenshot='figs/p/heat_output'  + str(index) + '.png', return_cpos=True)
    print(cpos)



if 1:
    pv.global_theme.show_scalar_bar = True
    i = 0

    mesh.point_data['T(K)'] = p_plot
    Max = np.max(p_plot)
    Min = np.min(p_plot)
    # Max_bar = np.max((abs(Max), abs(Min)))

    # Max_bar = 0.129
    # print('Max DON : ' , np.max(np.abs((D_recon[i,:] - D_real[i,:]))))
    pl = pv.Plotter(off_screen=True)

    sargs = dict(height=0.65,
                 vertical=True,
                 position_x=0.90,
                 position_y=0.20,
                 title_font_size=30,
                 label_font_size=25,
                 color='black',
                 font_family="arial")

    pl.add_mesh(mesh, scalars='T(K)', cmap='RdBu_r', scalar_bar_args=sargs)
    # pl.add_text('Max Error = ' + str(np.round(np.max(np.abs(D_recon[i,:] - D_real[i,:])), 3)) + 'mm',
    #             position='lower_edge', color='black', font='arial',
    #             shadow=True, font_size=14)
    pl.camera.position = (-98.24647470106407, 57.735116870463614, -152.91745928400286)
    pl.camera.focal_point = (104.24166297136696, -59.09799482571239, 186.75633167549972)
    pl.camera.up = (0.25296891917256037, 0.9512586611058352, 0.17639071858746022)
    pl.camera.zoom(1.6)

    pl.update_scalar_bar_range([Min, Max])
    # pl.screenshot(screenshot='fig/lbo_'+str(i)+'.png')
    cpos = pl.show(screenshot='figs/p/heat_pre'  + str(index) + '.png', return_cpos=True)
    print(cpos)

if 1:
    pv.global_theme.show_scalar_bar = True

    pl = pv.Plotter(off_screen=True)

    sargs = dict(height=0.65,
                 vertical=True,
                 position_x=0.05,
                 position_y=0.15,
                 title_font_size=30,
                 label_font_size=25,
                 color='black',
                 font_family="arial")

    pl.add_mesh(mesh, show_edges=True, color='white')
    # pl.add_text('Max Error = ' + str(np.round(np.max(np.abs(D_recon[i,:] - D_real[i,:])), 3)) + 'mm',
    #             position='lower_edge', color='black', font='arial',
    #             shadow=True, font_size=14)

    # pl.camera.position = (-14.88374544709646, -54.03095108702918, 31.60801263433601)
    # pl.camera.focal_point = (30.610810906854205, 151.93371605863288, -47.762922093537085)
    # pl.camera.up =  (0.412176133116136, -0.4054643405671868, -0.8159102302446304)
    pl.camera.position = (-98.24647470106407, 57.735116870463614, -152.91745928400286)
    pl.camera.focal_point = (104.24166297136696, -59.09799482571239, 186.75633167549972)
    pl.camera.up = (0.25296891917256037, 0.9512586611058352, 0.17639071858746022)
    pl.camera.zoom(1.6)
    pl.update_scalar_bar_range([Min, Max])
    # pl.screenshot(screenshot='fig/lbo_'+str(i)+'.png')
    cpos = pl.show(screenshot='figs/p/heat_mesh' + str(index) + '.png', return_cpos=True)







