import scipy.io as sio
import matplotlib.pyplot as plt
import matplotlib.tri as mtri
import numpy as np
# from lapy import TriaMesh
import matplotlib

matplotlib.rcParams['mathtext.fontset'] = 'cm' # 设置公式字体 STIX
plt.rc('font', family='arial', size=14)

PATH = '../data/01.darcy/mult_holes.mat'
result_path_DN = '../data/01.darcy/pre/DNORM_pre.mat'
result_path_DE = '../data/01.darcy/pre/DeepONet_pre.mat'
result_path_PO = '../data/01.darcy/pre/POD_DeepONet_pre.mat'
result_path_NO = '../data/01.darcy/pre/MeshNO_pre.mat'
data_mesh = sio.loadmat(PATH)
result_DN = sio.loadmat(result_path_DN)
result_DE = sio.loadmat(result_path_DE)
result_PO = sio.loadmat(result_path_PO)
result_NO = sio.loadmat(result_path_NO)
index = 1622
index_r = index -1400
Points = np.vstack((data_mesh['MeshNodes'], np.zeros(1119).reshape(1,-1)))
triang = mtri.Triangulation(data_mesh['MeshNodes'][0], data_mesh['MeshNodes'][1], data_mesh['MeshElements'].T-1)
y_test   = data_mesh['u_field'][index]
bc = data_mesh['f_bc'][index]
y_pre_DN = result_DN['pre_test'][index_r]
y_pre_DE = result_DE['pre_test'][index_r]
y_pre_PO = result_PO['pre_test'][index_r]
y_pre_NO = result_NO['pre_test'][index_r]

fig, axs = plt.subplots(figsize=(10,9))
plt.subplots_adjust(left=0.08, right=0.95,bottom=0.06,top=0.9,wspace=0.2)

segment = 'darcy'
grid = plt.GridSpec(2,3, wspace=0.15, hspace=0.15)


####### 01  Plot the mesh
# plt.subplot(grid[0,0])
# cs = plt.tricontourf(triang, y_test, np.linspace(3, 15, 5), cmap='binary', alpha=0.01)
# plt.triplot(triang,linewidth=0.5, markersize=0.2)
# cb = plt.colorbar(cs, location = 'bottom')
# cb.set_ticks([ ])
# plt.xlim([0,1])
# plt.ylim([0,1])
# plt.title('(a) Mesh ', fontsize=12)


####### 02  Plot the triangulation. input
# plt.subplot(grid[0,1])
# plt.plot(np.linspace(0, 1, 101),bc)
# cs = plt.tricontourf(triang, y_test, np.linspace(3, 15, 5), cmap='binary', alpha=0.01)
# cb = plt.colorbar(cs, location = 'bottom')
# cb.set_ticks([ ])
# plt.xlim([0,1])
# # plt.ylim([-2,2])
# plt.title('(b) Boundary Condition ', fontsize=12)

######### 03 Plot the triangulation.
plt.subplot(grid[0,0])
cs = plt.tricontourf(triang, y_test,  cmap='Blues')
# plt.triplot(triang,linewidth=0.05, markersize=0.01)
cb = plt.colorbar(cs, location = 'bottom')
cb.set_ticks([0.00, 0.50, 1.00,1.50,2.00])

plt.xlim([0,1])
plt.ylim([0,1])
plt.title('Ground truth', fontsize=16)

####### 04. Plot the pre result
plt.subplot(grid[0,1])
cs = plt.tricontourf(triang, y_pre_DN,  cmap='Blues')
# plt.triplot(triang,linewidth=0.05, markersize=0.01)
cb = plt.colorbar(cs, location = 'bottom')
cb.set_ticks([0.00, 0.50, 1.00,1.50,2.00])
plt.xlim([0,1])
plt.ylim([0,1])
plt.title('Predicted by BV-NORM', fontsize=16)

####### 05. Plot the pre error of deeponet hot_r
plt.subplot(grid[1,0])
ERROR = np.max(np.abs(y_test - y_pre_DE))
ERROR_mean = np.mean(np.abs(y_test - y_pre_DE))
cs = plt.tricontourf(triang, y_test - y_pre_DE, np.linspace(-0.035, 0.035,  20), cmap='RdBu_r')
# plt.triplot(triang_FNO,linewidth=0.1, markersize=0.1)
cb = plt.colorbar(cs, location = 'bottom')
cb.set_ticks([ -0.03,  0, 0.03])
plt.xlim([0,1])
plt.ylim([0,1])
plt.text(0.05, 0.7, r'${\Delta}_{mean}$ = '+ str(np.round(ERROR_mean, 4)),
         fontsize=14 )
plt.text(0.05, 0.6, r'${\Delta}_{max}$  = '+ str(np.round(ERROR, 4)),
         fontsize=14 )

plt.title('Error of DeepONet', fontsize=16)

####### 06. Plot the pre error of POD_deeponet
plt.subplot(grid[1,1])
ERROR = np.max(np.abs(y_test - y_pre_PO))
ERROR_mean = np.mean(np.abs(y_test - y_pre_PO))
cs = plt.tricontourf(triang, y_test - y_pre_PO, np.linspace(-0.035, 0.035, 20), cmap='RdBu_r')
# plt.triplot(triang_FNO,linewidth=0.1, markersize=0.1)
cb = plt.colorbar(cs, location = 'bottom')
cb.set_ticks([ -0.03,  0, 0.03])
plt.xlim([0,1])
plt.ylim([0,1])
plt.text(0.05, 0.7, r'${\Delta}_{mean}$ = '+ str(np.round(ERROR_mean, 4)),
         fontsize=14 )
plt.text(0.05, 0.6, r'${\Delta}_{max}$  = '+ str(np.round(ERROR, 4)),
         fontsize=14 )

plt.title('Error of POD-DeepONet', fontsize=16)

####### 07. Plot the pre error of NORM
plt.subplot(grid[1,2])
ERROR = np.max(np.abs(y_test - y_pre_NO))
ERROR_mean = np.mean(np.abs(y_test - y_pre_NO))
cs = plt.tricontourf(triang, y_test - y_pre_NO, np.linspace(-0.035, 0.035, 20), cmap='RdBu_r')
# plt.triplot(triang_FNO,linewidth=0.1, markersize=0.1)
cb = plt.colorbar(cs, location = 'bottom')
cb.set_ticks([ -0.03,  0, 0.03])
plt.xlim([0,1])
plt.ylim([0,1])
plt.text(0.05, 0.7, r'${\Delta}_{mean}$ = '+ str(np.round(ERROR_mean, 4)),
         fontsize=14 )
plt.text(0.05, 0.6, r'${\Delta}_{max}$  = '+ str(np.round(ERROR, 4)),
         fontsize=14 )

plt.title('Error of NORM', fontsize=16)

####### 08. Plot the pre error of DNORM RdBu_r
plt.subplot(grid[0,2])
ERROR = np.max(np.abs(y_test - y_pre_DN))
ERROR_mean = np.mean(np.abs(y_test - y_pre_DN))
cs = plt.tricontourf(triang, y_test - y_pre_DN, np.linspace(-0.035, 0.035,  20), cmap='RdBu_r')
# plt.triplot(triang_FNO,linewidth=0.1, markersize=0.1)
cb = plt.colorbar(cs, location = 'bottom')
cb.set_ticks([ -0.03,  0, 0.03])
plt.xlim([0,1])
plt.ylim([0,1])
plt.text(0.05, 0.7, r'${\Delta}_{mean}$ = '+ str(np.round(ERROR_mean, 4)),
         fontsize=14 )
plt.text(0.05, 0.6, r'${\Delta}_{max}$  = '+ str(np.round(ERROR, 4)),
         fontsize=14 )

plt.title('Error of BV-NORM', fontsize=16)

#####################################################
#####    SAVE
plt.savefig('darcy_1' + str(index) + '.svg',format='svg')
plt.savefig('darcy_1' + str(index) + '.pdf',format='pdf')

# plt.tight_layout()
plt.show()