FIG 1, 2, 3 :PPT
FIG 7 :Paraview