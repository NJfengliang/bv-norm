import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
import scipy.io as sio
from matplotlib.colors import ListedColormap
from matplotlib import cm
import warnings
import os

warnings.simplefilter("ignore")
os.environ['KMP_DUPLICATE_LIB_OK'] = 'True'

# Set matplotlib parameters for a consistent look
plt.rcParams['mathtext.fontset'] = 'cm'  # Set formula font to 'cm'
plt.rc('font', family='Arial', size=16)  # Set general font to 'Arial'

# Color bar setup
jet = cm.get_cmap('turbo', 256)
newcolors = jet(np.linspace(0.1, 1, 256))
newcmp = ListedColormap(newcolors)

# Load data
PATH = '../data/04.composite_qianyuan/pre/DNORM_pre.mat'
data = sio.loadmat(PATH)
index = 10
x_ = np.linspace(0, 300, 151)
y_1 = data['x_test'][index]
Name = "BC"

fig, ax = plt.subplots(figsize=(6, 6))  # Set the figure size

# Plot data with enhanced styles
ax.plot(x_, y_1[:, 0], linewidth=3, label='Inside', color='#1f5888')
ax.plot(x_, y_1[:, 1], linewidth=3, label='Outside', color='#820823')

# Enhance legend
ax.legend(loc='upper right', frameon=True, fontsize=30, title='Location', title_fontsize='32')

# Remove numerical labels on the axes
ax.set_xticks([])
ax.set_yticks([])

# Ensure all four spines are visible
for spine in ax.spines.values():
    spine.set_visible(True)
    spine.set_linewidth(1.5)  # Adjust the width as needed

# Remove top and right spines for a cleaner look
ax.spines['top'].set_visible(False)
ax.spines['right'].set_visible(False)

# Set axis labels with appropriate font sizes
ax.set_xlabel('Time (min)', fontsize=32)
ax.set_ylabel('Temperature (K)', fontsize=32)

# Enhance the grid
ax.grid(True, which='both', linestyle='--', linewidth=1, alpha=0.7)

# Save the plot with a tight layout
plt.tight_layout()
plt.savefig('figs/' + str(Name) + '.svg', format='svg')
plt.savefig('figs/' + str(Name) + '.pdf', format='pdf')

plt.show()
