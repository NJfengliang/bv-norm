# -*- coding: utf-8 -*-
"""
Created on Thu Nov 10 10:59:35 2022

@author: GengxiangCHEN
"""

import numpy as np
import pyvista as pv
import pandas as pd
import matplotlib.pyplot as plt
import torch
import matplotlib 
import scipy.io as sio
from matplotlib import cm
from pyvista import CellType

# matplotlib.rcParams['backend'] = 'SVG'
matplotlib.rcParams['mathtext.fontset'] = 'cm' # 设置公式字体 STIX 
plt.rc('font', family='arial', size=16)
pv.rcParams['transparent_background'] = True
from matplotlib.colors import ListedColormap, LinearSegmentedColormap

import warnings
warnings.simplefilter("ignore")
import os
os.environ['KMP_DUPLICATE_LIB_OK']='True'


########## Color bar ################
jet = cm.get_cmap('turbo', 256)
newcolors = jet(np.linspace(0.1, 1, 256))
newcmp = ListedColormap(newcolors)

#####################################
output_mesh_points = sio.loadmat('../data/04.composite_qianyuan/Qianyuan_T2.mat')
points = output_mesh_points['nodes']
faces  = output_mesh_points['elements'] - 1
faces  = faces.astype(int)

celltypes = np.full(faces.shape[0], fill_value=CellType.TETRA, dtype=np.uint8)
cells     = np.hstack((np.full((faces.shape[0], 1), 4), faces))

mesh = pv.UnstructuredGrid(cells, celltypes, points)
# mesh.plot(show_axes=True, show_edges=True)
# cpos = pl.show(screenshot='figs/000_'+str(i)+'.png', return_cpos=False)
# print(cpos)
index = 10

# PATH = '../data/04.composite_qianyuan/pre/DNORM_pre.mat'
# data = sio.loadmat(PATH)
# # x_data = data['input']

PATH = '../data/04.composite_qianyuan/Qianyuan_T2.mat'
result_path_DN = '../data/04.composite_qianyuan/pre/DNORM_pre.mat'
result_path_DE = '../data/04.composite_qianyuan/pre/DeepONet_pre.mat'
result_path_PO = '../data/04.composite_qianyuan/pre/POD_DeepONet_pre.mat'
result_path_NO = '../data/04.composite_qianyuan/pre/MeshNO_pre.mat'
data_mesh = sio.loadmat(PATH)
result_DN = sio.loadmat(result_path_DN)
result_DE = sio.loadmat(result_path_DE)
result_PO = sio.loadmat(result_path_PO)
result_NO = sio.loadmat(result_path_NO)

y_true = result_DN['y_test'][index]
DN_data = result_DN['pre_test'][index]
DE_data = result_DE['pre_test'][index]
PO_data = result_PO['pre_test'][index]
NO_data = result_NO['pre_test'][index]

print(max(NO_data-y_true))
print(max(DN_data-y_true))
print(max(DE_data-y_true))
print(max(PO_data-y_true))
Name = "truth"

# y_plot   = y_data[index]

delt = y_true
# delt = y_true

# x_plot = x_data[index]
# y_plot = y_data[index]
########### ReduceOeder ########
# dataGP = sio.loadmat('../data/GP_modes_100_pre_200.mat')
# D_reald_GP = dataGP['y_test_Deform']
# D_recon_GP = dataGP['pre_test_Deform']

##### Plot SVD Fig #####
if 1:
    pv.global_theme.show_scalar_bar = True
    i = 0

    mesh.point_data['D(mm)'] = delt
    # Max = np.max(delt)
    # Min = np.min(delt)
    Max = 2.6
    Min = -0.1
    # Max_bar = np.max((abs(Max), abs(Min)))

    # Max_bar = 0.129
    # print('Max DON : ' , np.max(np.abs((D_recon[i,:] - D_real[i,:]))))
    pl = pv.Plotter(off_screen=True)

    sargs = dict(height=0.65,
                 vertical=True,
                 position_x=0.75,
                 position_y=0.15,
                 title_font_size=50,
                 label_font_size=50,
                 color = 'black',
                 font_family="arial")

    pl.add_mesh(mesh, scalars='D(mm)', cmap='RdBu_r', scalar_bar_args=sargs)
    # pl.add_text('Max Error = ' + str(np.round(np.max(np.abs(D_recon[i,:] - D_real[i,:])), 3)) + 'mm',
    #             position='lower_edge', color='black', font='arial',
    #             shadow=True, font_size=14)rainbow RdBu_r
    pl.camera.focal_point = (69.19873218276595, 49.16706489155614, 100.40872376040254)
    pl.camera.position = (-75.24146825310596, 272.64499386658304, 597.2672618941065)
    pl.camera.up = (-0.9600268702094329, -0.21062569445502982, -0.1843508212924943)
    pl.camera.zoom(1)
    pl.update_scalar_bar_range([Min, Max])
    # pl.screenshot(screenshot='fig/lbo_'+str(i)+'.png')
    cpos = pl.show(screenshot='figs/'+str(Name)+'.png', return_cpos=True)
    print(cpos)
    
if 1:
    pv.global_theme.show_scalar_bar = True

    pl = pv.Plotter(off_screen=True)

    sargs = dict(height=0.65,
                 vertical=True,
                 position_x=0.05,
                 position_y=0.15,
                 title_font_size=30,
                 label_font_size=25,
                 color = 'black',
                 font_family="arial")

    pl.add_mesh(mesh, show_edges=True, color='white')
    # pl.add_text('Max Error = ' + str(np.round(np.max(np.abs(D_recon[i,:] - D_real[i,:])), 3)) + 'mm',
    #             position='lower_edge', color='black', font='arial',
    #             shadow=True, font_size=14)

    # pl.camera.position = (-14.88374544709646, -54.03095108702918, 31.60801263433601)
    # pl.camera.focal_point = (30.610810906854205, 151.93371605863288, -47.762922093537085)
    # pl.camera.up =  (0.412176133116136, -0.4054643405671868, -0.8159102302446304)
    pl.camera.focal_point = (69.19873218276595, 49.16706489155614, 100.40872376040254)
    pl.camera.position = (-75.24146825310596, 272.64499386658304, 597.2672618941065)
    pl.camera.up = (-0.9600268702094329, -0.21062569445502982, -0.1843508212924943)
    pl.camera.zoom(1)
    pl.update_scalar_bar_range([Min, Max])
    # pl.screenshot(screenshot='fig/lbo_'+str(i)+'.png')
    cpos = pl.show(screenshot='figs/qianyuan_mesh'+str(index)+'.png', return_cpos=True)
    print(cpos)



if 1:
    pv.global_theme.show_scalar_bar = True
    i = 0

    mesh.point_data['$delt$ D(mm)'] = DN_data
    # Max = np.max(delt)
    # Min = np.min(delt)
    Max = 2.6
    Min = -0.1
    # Max_bar = np.max((abs(Max), abs(Min)))

    # Max_bar = 0.129
    # print('Max DON : ' , np.max(np.abs((D_recon[i,:] - D_real[i,:]))))
    pl = pv.Plotter(off_screen=True)

    sargs = dict(height=0.65,
                 vertical=True,
                 position_x=0.75,
                 position_y=0.15,
                 title_font_size=35,
                 label_font_size=35,
                 color = 'black',
                 font_family="arial")

    pl.add_mesh(mesh, scalars='D(mm)', cmap='RdBu_r', scalar_bar_args=sargs)
    # pl.add_text('Max Error = ' + str(np.round(np.max(np.abs(D_recon[i,:] - D_real[i,:])), 3)) + 'mm',
    #             position='lower_edge', color='black', font='arial',
    #             shadow=True, font_size=14)rainbow RdBu_r
    pl.camera.focal_point = (69.19873218276595, 49.16706489155614, 100.40872376040254)
    pl.camera.position = (-75.24146825310596, 272.64499386658304, 597.2672618941065)
    pl.camera.up = (-0.9600268702094329, -0.21062569445502982, -0.1843508212924943)
    pl.camera.zoom(1)
    pl.update_scalar_bar_range([Min, Max])
    # pl.screenshot(screenshot='fig/lbo_'+str(i)+'.png')
    cpos = pl.show(screenshot='figs/'+'DN_data.png', return_cpos=True)
    print(cpos)


if 1:
    pv.global_theme.show_scalar_bar = True
    i = 0

    mesh.point_data['D(mm)'] = DN_data-y_true
    # Max = np.max(delt)
    # Min = np.min(delt)
    Max = 0.15
    Min = -0.1
    # Max_bar = np.max((abs(Max), abs(Min)))

    # Max_bar = 0.129
    # print('Max DON : ' , np.max(np.abs((D_recon[i,:] - D_real[i,:]))))
    pl = pv.Plotter(off_screen=True)

    sargs = dict(height=0.65,
                 vertical=True,
                 position_x=0.75,
                 position_y=0.15,
                 title_font_size=35,
                 label_font_size=35,
                 color = 'black',
                 font_family="arial")

    pl.add_mesh(mesh, scalars='D(mm)', cmap='RdBu_r', scalar_bar_args=sargs)
    # pl.add_text('Max Error = ' + str(np.round(np.max(np.abs(D_recon[i,:] - D_real[i,:])), 3)) + 'mm',
    #             position='lower_edge', color='black', font='arial',
    #             shadow=True, font_size=14)rainbow RdBu_r
    pl.camera.focal_point = (69.19873218276595, 49.16706489155614, 100.40872376040254)
    pl.camera.position = (-75.24146825310596, 272.64499386658304, 597.2672618941065)
    pl.camera.up = (-0.9600268702094329, -0.21062569445502982, -0.1843508212924943)
    pl.camera.zoom(1)
    pl.update_scalar_bar_range([Min, Max])
    # pl.screenshot(screenshot='fig/lbo_'+str(i)+'.png')
    cpos = pl.show(screenshot='figs/'+'DN.png', return_cpos=True)
    print(cpos)


if 1:
    pv.global_theme.show_scalar_bar = True
    i = 0

    mesh.point_data['D(mm)'] = DE_data-y_true
    # Max = np.max(delt)
    # Min = np.min(delt)
    Max = 0.15
    Min = -0.1
    # Max_bar = np.max((abs(Max), abs(Min)))

    # Max_bar = 0.129
    # print('Max DON : ' , np.max(np.abs((D_recon[i,:] - D_real[i,:]))))
    pl = pv.Plotter(off_screen=True)

    sargs = dict(height=0.65,
                 vertical=True,
                 position_x=0.75,
                 position_y=0.15,
                 title_font_size=50,
                 label_font_size=50,
                 color = 'black',
                 font_family="arial")

    pl.add_mesh(mesh, scalars='D(mm)', cmap='RdBu_r', scalar_bar_args=sargs)
    # pl.add_text('Max Error = ' + str(np.round(np.max(np.abs(D_recon[i,:] - D_real[i,:])), 3)) + 'mm',
    #             position='lower_edge', color='black', font='arial',
    #             shadow=True, font_size=14)rainbow RdBu_r
    pl.camera.focal_point = (69.19873218276595, 49.16706489155614, 100.40872376040254)
    pl.camera.position = (-75.24146825310596, 272.64499386658304, 597.2672618941065)
    pl.camera.up = (-0.9600268702094329, -0.21062569445502982, -0.1843508212924943)
    pl.camera.zoom(1)
    pl.update_scalar_bar_range([Min, Max])
    # pl.screenshot(screenshot='fig/lbo_'+str(i)+'.png')
    cpos = pl.show(screenshot='figs/'+'DE.png', return_cpos=True)
    print(cpos)

if 1:
    pv.global_theme.show_scalar_bar = True
    i = 0

    mesh.point_data['D(mm)'] = PO_data-y_true
    # Max = np.max(delt)
    # Min = np.min(delt)
    Max = 0.15
    Min = -0.1
    # Max_bar = np.max((abs(Max), abs(Min)))

    # Max_bar = 0.129
    # print('Max DON : ' , np.max(np.abs((D_recon[i,:] - D_real[i,:]))))
    pl = pv.Plotter(off_screen=True)

    sargs = dict(height=0.65,
                 vertical=True,
                 position_x=0.75,
                 position_y=0.15,
                 title_font_size=50,
                 label_font_size=50,
                 color = 'black',
                 font_family="arial")

    pl.add_mesh(mesh, scalars='D(mm)', cmap='RdBu_r', scalar_bar_args=sargs)
    # pl.add_text('Max Error = ' + str(np.round(np.max(np.abs(D_recon[i,:] - D_real[i,:])), 3)) + 'mm',
    #             position='lower_edge', color='black', font='arial',
    #             shadow=True, font_size=14)rainbow RdBu_r
    pl.camera.focal_point = (69.19873218276595, 49.16706489155614, 100.40872376040254)
    pl.camera.position = (-75.24146825310596, 272.64499386658304, 597.2672618941065)
    pl.camera.up = (-0.9600268702094329, -0.21062569445502982, -0.1843508212924943)
    pl.camera.zoom(1)
    pl.update_scalar_bar_range([Min, Max])
    # pl.screenshot(screenshot='fig/lbo_'+str(i)+'.png')
    cpos = pl.show(screenshot='figs/'+'PO.png', return_cpos=True)
    print(cpos)

if 1:
    pv.global_theme.show_scalar_bar = True
    i = 0

    mesh.point_data['D(mm)'] = NO_data-y_true
    # Max = np.max(delt)
    # Min = np.min(delt)
    Max = 0.15
    Min = -0.1
    # Max_bar = np.max((abs(Max), abs(Min)))

    # Max_bar = 0.129
    # print('Max DON : ' , np.max(np.abs((D_recon[i,:] - D_real[i,:]))))
    pl = pv.Plotter(off_screen=True)

    sargs = dict(height=0.65,
                 vertical=True,
                 position_x=0.75,
                 position_y=0.15,
                 title_font_size=50,
                 label_font_size=50,
                 color = 'black',
                 font_family="arial")

    pl.add_mesh(mesh, scalars='D(mm)', cmap='RdBu_r', scalar_bar_args=sargs)
    # pl.add_text('Max Error = ' + str(np.round(np.max(np.abs(D_recon[i,:] - D_real[i,:])), 3)) + 'mm',
    #             position='lower_edge', color='black', font='arial',
    #             shadow=True, font_size=14)rainbow RdBu_r
    pl.camera.focal_point = (69.19873218276595, 49.16706489155614, 100.40872376040254)
    pl.camera.position = (-75.24146825310596, 272.64499386658304, 597.2672618941065)
    pl.camera.up = (-0.9600268702094329, -0.21062569445502982, -0.1843508212924943)
    pl.camera.zoom(1)
    pl.update_scalar_bar_range([Min, Max])
    # pl.screenshot(screenshot='fig/lbo_'+str(i)+'.png')
    cpos = pl.show(screenshot='figs/'+'NO.png', return_cpos=True)
    print(cpos)



    
    

                
    