import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
import scipy.io as sio
from matplotlib.colors import ListedColormap
from matplotlib import cm
import warnings
import os

warnings.simplefilter("ignore")
os.environ['KMP_DUPLICATE_LIB_OK'] = 'True'

# Set matplotlib parameters for a consistent look
plt.rcParams['mathtext.fontset'] = 'cm'  # Set formula font to 'cm'
plt.rc('font', family='Arial', size=16)  # Set general font to 'Arial'

# Color bar setup
jet = cm.get_cmap('turbo', 256)
newcolors = jet(np.linspace(0.1, 1, 256))
newcmp = ListedColormap(newcolors)

# Load data
PATH = '../data/04.composite_qianyuan/pre/DNORM_pre.mat'
data = sio.loadmat(PATH)
index = 10
x_ = np.linspace(0, 300, 151)
y_1 = data['x_test'][index]
Name = "BC"

fig, ax = plt.subplots(figsize=(7, 6))  # Set the figure size

# Plot data with enhanced styles
ax.plot(x_, y_1[:, 0], linewidth=3, label='Inside', color='#738ba8')
ax.plot(x_, y_1[:, 1], linewidth=3, label='Outside', color='#a56866')

# Enhance legend
ax.legend(loc='best', frameon=True, fontsize=30)
'''
'best' (default): Automatically chooses the best location for the legend.
'upper right': Upper right corner.
'upper left': Upper left corner.
'lower left': Lower left corner.
'lower right': Lower right corner.
'right': Centered on the right edge.
'center left': Centered on the left edge.
'center right': Centered on the right edge.
'lower center': Centered at the bottom.
'upper center': Centered at the top.
'center': Centered in the plot area.'''

# Remove numerical labels on the axes
ax.set_xticks([])
ax.set_yticks([])

# Remove all spines
for spine in ax.spines.values():
    spine.set_visible(False)

# Set axis labels with appropriate font sizes
ax.set_xlabel('Time (min)', fontsize=32)
ax.set_ylabel('Temperature (K)', fontsize=32)

# Enhance the grid
ax.grid(True, which='both', linestyle='--', linewidth=1, alpha=0.7)

# Save the plot with a tight layout
plt.tight_layout()
plt.savefig('figs/' + str(Name) + '.svg', format='svg')
plt.savefig('figs/' + str(Name) + '.pdf', format='pdf')

plt.show()
